        <!-- Admin Dashboard -->
        <div class="admin-dashboard">
            <p style="letter-spacing: 1px; text-transform: uppercase; cursor: pointer; text-align: center;">Admin Pages</p>
            <hr>

            <div class="admin-choices-container">
                <div class="choices-container">
                    <button class="choices">Add Item</button>
                </div>
                <div class="choices-container">
                    <button class="choices">Edit Item</button>
                </div>
                <div class="choices-container">
                    <button class="choices">User Order</button>
                </div>
            </div>
        </div>