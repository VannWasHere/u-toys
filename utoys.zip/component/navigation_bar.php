    <!-- Navigation Bar Container -->
    <div class="navigation-bar-container">
        <nav>
            <ul id="navigation-ul">
                <a href="index.php">Home</a>
                <a href="about.php">About</a>
                <a href="product.php">Product</a>
                <a href="customer_support.php">Contact Us</a>
            </ul>
        </nav>
    </div>