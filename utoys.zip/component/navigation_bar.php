    <!-- Navigation Bar Container -->
    <div class="navigation-bar-container">
        <nav>
            <div class="logo">
                <h2>Logo</h2>
            </div>
            <ul id="navigation-ul">
                <a href="index.php">Home</a>
                <a href="about.html">About</a>
                <a href="product.php">Product</a>
                <a href="">Contact Us</a>
            </ul>
        </nav>
    </div>