<?php
    error_reporting(E_ERROR);
?>