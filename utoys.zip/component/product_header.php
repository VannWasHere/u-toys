        <div class="product-header">
            <p id="header-title">Our Products</p>

            <div class="category-grid-container">
                <div id="puzzle-div" onclick="location.href='product.php?cat=puzzle'" class="grid-category">
                    <h3>Puzzle</h3>
                </div>
                <div id="rubic-div" onclick="location.href='product.php?cat=rubic'" class="grid-category">
                    <h3>Rubik</h3>
                </div>
                <div id="board-div" onclick="location.href='product.php?cat=board-game'" class="grid-category">
                    <h3>Board Game</h3>
                </div>
                <div id="card-div" onclick="location.href='product.php?cat=card-game'" class="grid-category">
                    <h3>Card Game</h3>
                </div>
            </div>
        </div>