<?php

/* Local Host */
$server = "localhost";
$username = "root";
$password = "";
$database = "utoys";

$conn = mysqli_connect($server, $username, $password, $database);