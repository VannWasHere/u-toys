<?php

/* Local Host */
$server = "localhost";
$username = "root";
$password = "";
$database = "utoys";

/* Dewaweb */
// $server = "localhost";
// $username = "root";
// $password = "";
// $database = "utoysmyi_utoys";

$conn = mysqli_connect($server, $username, $password, $database);